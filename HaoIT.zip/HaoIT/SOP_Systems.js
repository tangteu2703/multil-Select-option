﻿const baseUrl = "/SOPSystem/";
let myList = new ListItem();

$(document).ready(function () {
    showHideSideBar();
    loadUrlValue();
    loadData();
    $(".modal").draggable();
});

const loadUrlValue = () => {
    var urlSearchParams = new URLSearchParams(window.location.search);
    var codeSOP = urlSearchParams.get('CodeSOP');
    $('#txtS_CodeSOP').val(codeSOP);
}

const loadData = () => {

    $("#table_data").dataTable().fnDestroy();
    $('#searchModel').prop('disabled', true);
    var dataTable = $("#table_data").DataTable({
        "destroy": true,
        "lengthChange": true,
        "language": {
            "info": "Show _START_ - _END_ ( Total: _TOTAL_ )",
            "infoEmpty": "Showing 0 - 0 ",
            "infoFiltered": "( Total: _MAX_ )",
            "lengthMenu": "Show _MENU_ ",
            "search": "Search:",
            "loadingRecords": "Loading ... ",
            "paginate": {
                'previous': '<',
                'next': '>',
                'last': '>>',
                'first': '<<'
            },
        },
        "lengthMenu": [5, 10, 25, 50, 100],
        "pageLength": 10,
        "filter": true, // this is for disable filter (search box)
        "orderMulti": false, // for disable multiple column at once
        "sort": true,
        "ajax": {
            url: baseUrl + "LoadData",
            data: {
                CodeSop: $('#txtS_CodeSOP').val(),
                Contents: $('#cboS_Contents').val(),
                NameSop: $('#txtS_NameSOP').val(),
                IsType: $('#cboS_Type').val(),
                IsActive: $('#cboS_Active').val(),
                IsTemporary: $('#cboS_Temporary').val(),
            },
            type: "POST",
            dataType: "json",
        },
        "columns": [
            { "data": "Id", "autoWidth": false },
            { "data": "IsType", "autoWidth": false },
            { "data": "CodeSop", "autoWidth": false },
            { "data": "Model", "autoWidth": false },
            { "data": "NameSop", "autoWidth": false },
            { "data": "Contents", "autoWidth": false },
            {
                "data": "VersionDate", "autoWidth": false,
                render: function (data, type, row) {
                    var date = data != null ? moment(data).format('DD/MM/YYYY') : '';
                    return `<p>${date}</p>`;
                },
            },
            { "data": "DeptIssue", "autoWidth": false },
            { "data": "DeptUser", "autoWidth": false },
            {
                "data": "FileName", "autoWidth": false,
                render: function (data, type, row) {
                    return `<i class="text-primary" onclick="clickView(${row.Id},'GetIDRecord')"> ${data}</b>`;
                },
            },
            {
                "data": "IsActive",
                render: function (data, type, row) {
                    var html = '';
                    if (row.DueDate != null) {
                        var Day = moment(row.DueDate).format('yyyyMMDD');
                        var currentDay = moment(new Date()).format('yyyyMMDD');
                        if (Day < currentDay)
                            data = 2;
                    }
                    if (data == 1)
                        html = `<span class="badge badge-success">Đang sử dụng</span>`;
                    else if (data == 0)
                        html = `<span class="badge badge-danger">Hủy bỏ</span>`;
                    else
                        html = `<span class="badge badge-warning">Hết hạn</span>`;
                    return html;
                },
            },
            {
                "data": "IsTemporary", "autoWidth": false,
                render: function (data, type, row) {
                    var html = '';
                    if (data == 1)
                        html = `<button type="button" class="btn btn-sm btn-outline-success"><i class="fa fa-check-square"></i></button>`;
                    return html;
                },
            },
            {
                "data": "DueDate", "autoWidth": false,
                render: function (data, type, row) {
                    var btn = '';
                    var date = data != null ? moment(data).format('DD/MM/YYYY') : '';
                    if (data != null) {
                        var Day = moment(data).format('yyyyMMDD');
                        var currentDay = moment(new Date()).format('yyyyMMDD');
                        if (Day < currentDay) {
                            btn = "badge badge-danger"
                        } else if (Day - currentDay <= 5) {
                            btn = "badge badge-warning"
                        }
                    }
                    return `<p class="${btn}">${date}</p>`;
                },
            },
            { "data": "CreatedBy", "autoWidth": false },
            {
                data: "Id",
                render: function (data, type, row) {
                    let btnHtml = ``;
                    if (isDeptManagement) {
                        if (row.IsActive > 0) {
                            btnHtml = `<li><a onclick ="historyChange(${row.Id},true)" class="dropdown-item text-warning" href="#"><i class="fa fa-arrow-circle-o-left"></i>Back version</a></li>
                                   <li><a onclick ="openChange(${row.Id},'version')" class="dropdown-item text-success" href="#"><i class="fa fa-arrow-circle-o-up"></i>Up version</a></li>
                                   <li><a onclick ="openChange(${row.Id},'edit')" class="dropdown-item text-primary" href="#"><i class="fa fa-edit"></i>Edit SOP</a></li>
                                   <li><a onclick ="cancelChange(${row.Id})" class="dropdown-item text-danger" href="#"><i class="fa fa-toggle-off"></i> Cancel SOP</a></li>`;
                        } else
                            btnHtml = `<li><a onclick ="openChange(${row.Id},'edit')" class="dropdown-item text-primary" href="#"><i class="fa fa-edit"></i>Edit SOP</a></li>`;

                    }
                    if (isAdmin)
                        btnHtml += `<li><a onclick="deleteChange(${row.Id})" class="dropdown-item text-danger" href="#"><i class="fa fa-trash"></i> Delete SOP</a></li>`;

                    let html = `<div class="dropdown">
                                  <a class="btn btn-sm btn-outline-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink${data}" data-toggle="dropdown" aria-expanded="false">
                                   Options
                                  </a>
                                
                                  <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink${data}">
                                    <li><a onclick ="openChecksheet(${row.Id})" class="dropdown-item text-primary" href="#"><i class="fa fa-calendar-check-o"></i>Check Sheet</a></li>
                                    <li><a onclick="historyChange(${row.Id},false)" class="dropdown-item" href="#"><i class="fa fa-history"></i>History</a></li>
                                    ${btnHtml}
                                  </ul>
                                </div>`;

                    return html;
                },
            },
        ],
        "columnDefs": [
            { "className": "text-center", "targets": "_all" },
        ],
        "initComplete": function (row, data, index) {
            $('#searchModel').prop('disabled', false);
        },
        // scrollX: true,
    });
}
const clearChange = () => {
    listFile = [];
    $('#txt_ID').val(0);
    $('#cbo_Type').prop('disabled', false);
    $('#txt_CodeSop').val('');
    $('#txt_ModelSop').val('');
    $('#txt_NameSop').val('');
    $('#txt_Contents').val('');
    $('#txt_Notes').val('');
    $('#txt_DeptIssues').val('');
    $('#txt_DeptUsers').val('');
    $('#txt_FileName').val('');
    $("#ckb_IsTemporary").prop("checked", false);
    $('#txt_DueDate').val('');
    $(".view-file-select").html("");

    $('.approve-group').hide();
}
const openModal = () => {
    var value = $('#txt_StatusAction').val();
    if (value == "back") {
        $("#title_header").html("Cập nhật version trước đó");
        $('#cbo_Type').prop('disabled', true);

    } else if (value == "version") {
        $("#title_header").html("Cập nhật version mới");
        $('#cbo_Type').prop('disabled', true);

    } else if (value == "edit") {
        $("#title_header").html("Chỉnh sửa tài liệu");
        $('#cbo_Type').prop('disabled', true);

    } else {
        $("#title_header").html("Tạo mới tài liệu");
        $('#cbo_Type').prop('disabled', false);
    }
    $("#modal_Details").modal("show");
}
const addChange = () => {
    clearChange();
    $('.approve-group').show();
    $('#txt_StatusAction').val('add');
    openModal();
}
const saveChange = () => {

    var iId = $('#txt_ID');
    var cboType = $('#cbo_Type');
    var txtNameSop = $('#txt_NameSop');
    var txt_CodeSop = $('#txt_CodeSop');
    var txt_ModelSop = $('#txt_ModelSop');
    var txtContents = $('#txt_Contents');
    var txtNotes = $('#txt_Notes');
    var txtDeptIssues = $('#txt_DeptIssues');
    var txtDeptUsers = $('#txt_DeptUsers');
    var ckbIsTemporary = $('#ckb_IsTemporary').prop("checked");
    var txtDueDate = $('#txt_DueDate').val();
    var txtComments = $('#txt_Comments').val();

    if (ckbIsTemporary) {
        if (txtDueDate.length > 0) {
            var dueDate = moment(txtDueDate).format("YYYY-MM-DD") >= moment(new Date()).format("YYYY-MM-DD");;
            if (!dueDate) {
                toastr.warning("Ngày hết hạn phải lớn hơn hoặc bằng ngày hiện tại!", "Warning");
                return false;
            }
        } else {
            toastr.warning("Ngày hết hạn không được để trống!", "Warning");
            $('#txt_DueDate').focus();
            return false;
        }
    } else {
        $('#txt_DueDate').val('');
    }

    if (!IsNullOrEmpty("warning", txtNameSop, `Tên SOP không được để trống!`)
        || !IsNullOrEmpty("warning", txt_CodeSop, `Mã SOP không được để trống!`)
        || !IsNullOrEmpty("warning", txt_ModelSop, `Model không được để trống!`)
        || !IsNullOrEmpty("warning", txtContents, `Công đoạn không được để trống!`)
        || !IsNullOrEmpty("warning", txtNotes, `Mail không được để trống!`)
        || !IsNullOrEmpty("warning", txtDeptIssues, `Phòng phát hành không được để trống!`)
        || !IsNullOrEmpty("warning", txtDeptUsers, `Phòng tiếp nhận không được để trống!`)) {
        return false;
    }
    if (listFile.length == 0) {
        toastr.warning("Không tìm thấy file cần thay đổi! <br/>  Vui lòng thao tác lại!", "Warning");
        return false;
    }
    let action = baseUrl + "UpdateRecords";
    let datasend = {
        model: {
            Id: iId.val(),
            IsType: cboType.val().trim(),
            CodeSop: txt_CodeSop.val().trim(),
            Model: txt_ModelSop.val().trim(),
            NameSop: txtNameSop.val().trim(),
            Contents: txtContents.val(),
            Notes: txtNotes.val(),
            DeptIssue: txtDeptIssues.val(),
            DeptUser: txtDeptUsers.val(),
            IsTemporary: ckbIsTemporary == true ? 1 : 0,
            DueDate: txtDueDate,
        },
        fileAction: listFile,
        Comments: txtComments
    }
    LoadingShow();
    PostDataAjax(action, datasend, function (response) {
        LoadingHide();
        if (response.rs) {

            $("#modal_Details").modal("hide");
            toastr.success(response.msg, "Success");
            loadData();
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const openChange = (key, value, select = "all", viewID = "file-select") => {

    $('#txt_StatusAction').val(value);
    listFile = [];

    let action = baseUrl + "GetIDRecord";
    let datasend = {
        Id: key,
    }
    LoadingShow();
    PostDataAjax(action, datasend, function (response) {
        LoadingHide();
        if (response.rs) {
            clearChange();
            openModal();
            var datas = response.data;
            $('#txt_ID').val(datas.Id);
            $('#cbo_Type').val(datas.IsType);
            $('#txt_CodeSopOld').val(datas.CodeSop);
            $('#txt_CodeSop').val(datas.CodeSop);
            $('#txt_ModelSop').val(datas.Model);
            $('#txt_NameSop').val(datas.NameSop);
            $('#txt_Contents').val(datas.Contents);
            $('#txt_DeptIssues').val(datas.DeptIssue);
            $('#txt_DeptUsers').val(datas.DeptUser);
            $('#txt_Notes').val(datas.Notes);

            $("#ckb_IsTemporary").prop("checked", datas.IsTemporary == 1 ? true : false);
            $('#txt_DueDate').val(datas.DueDate != null ? moment(datas.DueDate).format('YYYY-MM-DD') : '');

            listFile = response.fileAction;
            viewFileToSelect(select, viewID);

            // setTimeout(listFile = [], 300);
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const cancelChange = (id) => {
    $('#txtH_ID').val(id)
    $("#modal_Confirm").modal("show");
}
const confirmCancelChange = () => {

    var txtID = $('#txtH_ID');
    var txtEmail = $('#txtH_Email');
    var txtComments = $('#txtH_Comments');
    if (!IsNullOrEmpty("warning", txtEmail, `Email không được để trống!`)
        || !IsNullOrEmpty("warning", txtComments, `Lý do hủy không được để trống!`)) {
        return false;
    }
    let action = baseUrl + "ConfirmCancelRecord";
    let datasend = {
        Id: txtID.val(),
        Contents: txtEmail.val().trim(),
        Notes: txtComments.val(),
    }
    LoadingShow();
    PostDataAjax(action, datasend, function (response) {
        LoadingHide();
        if (response.rs) {
            $("#modal_Confirm").modal("hide");
            toastr.success(response.msg, "Success");
            loadData();
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const deleteChange = (id) => {

    let action = baseUrl + "ConfirmDeleteRecord";
    let datasend = {
        Id: id,
    }
    confirmJquery2(action, datasend, 'data');
}

///Check sheet
const openChecksheet = (id) => {
    let action = baseUrl + "GetCheckSheetSOP";
    let datasend = {
        Id: id,
    }
    LoadingShow();
    PostDataAjax(action, datasend, function (response) {
        LoadingHide();
        if (response.rs) {
            $('#txtC_IdSOP').val(id);

            listFile = response.fileAction;
            viewFileSOP('all', 'view-file-checksheet');
            $("#modal_CheckSheet").modal("show");
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const saveChangeCheckSheet = () => {
    var IdSOP = $('#txtC_IdSOP');
    if (!IsNullOrEmpty("warning", IdSOP, `SOP không tìm thấy! Vui lòng thao tác lại...`))
        return false;

    if (listFile.length == 0) {
        toastr.warning("Không tìm thấy file! <br/>  Vui lòng thao tác lại!", "Warning");
        return false;
    }
    let action = baseUrl + "UpdateCheckSheetSOP";
    let datasend = {
        IdSOP: IdSOP.val(),
        fileAction: listFile,
    }
    LoadingShow();
    PostDataAjax(action, datasend, function (response) {
        LoadingHide();
        if (response.rs) {
            $("#modal_CheckSheet").modal("hide");
            toastr.success(response.msg, "Success");
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const fileChangeToView_v4 = (key = '', select = "all", viewID = "view-file-select") => {
    //listFile = [];
    if (window.FormData !== undefined) {
        let fileUpload = $(`#${key}`).get(0);
        let files = fileUpload.files;
        let fileData = new FormData();
        for (let i = 0; i < files.length; i++) {
            fileData.append("file" + i, files[i]);
        }
        LoadingShow();
        $.ajax({
            url: '/Base/UploadFilesToBase64_v3',
            method: 'POST',
            contentType: false,
            processData: false,
            data: fileData,
            success: function (result) {
                if (result.rs) {
                    LoadingHide();
                    toastr.success(result.msg, "Success");
                    listFile = listFile.concat(result.data);

                    viewFileSOP('all', 'view-file-checksheet');
                } else {
                    LoadingHide();
                    toastr.warning(result.msg, "warning");
                }
            },
        });
    } else {
        toastr.error("FormData is not supported.");
    }
}
const viewFileSOP = (select = 'all', viewID = '') => {

    var html = '';
    listFile.map(e => {
        if (select.includes('all')) {
            var btnDelete = isDeptManagement? e.Id != null ? `<button type="button" onclick="hideFile('${e.guiId}','${e.Id}')" class="btn btn-sm btn-outline-danger" title="Delete"><i class="fa fa-trash"></i></button>`
                : ` <button type="button" onclick="hideFile('${e.guiId}','${e.Id}')" class="btn btn-sm btn-outline-dark" title="Delete"><i class="fa fa-minus"></i></button>`:``;
            html += ` <div class="row ml-0 pb-1 border-bottom">
                                         <div class="col-md-7 p-0">
                                           <b class="d-block">${e.FileName}</b>
                                           <i class="font-size-13">${e.ContentLength}</i>
                                         </div>
                                         <div class="col-md-5 pt-1 p-0"  style="text-align:right">
                                             <button type="button" onclick="downloadFile2('${e.guiId}')" class="btn btn-sm btn-outline-primary" title="Download"><i class="fa fa-download"></i></button>                           
                                             <button type="button" onclick="createModal_body('${e.guiId}')" class="btn btn-sm btn-outline-warning" title="View"><i class="fa fa-eye"></i></button>
                                            ${btnDelete}
                                         </div>
                                     </div>`;
        } else {
            html += `<i onclick="createModal_body('${x.guiId}')" class="mr-3">${x.FileName}</i>`;
        }
    })
    $(`.${viewID}`).html('').html(html);
}
const hideFile = (guiId, id) => {

    if (id == 'null') {
        listFile = listFile.filter(x => x.guiId !== guiId);
        viewFileSOP('all', 'view-file-checksheet');
    } else {
        let action = baseUrl + "DeleteCheckSheetSOP";
        let strContent = 'Are you sure you want to delete?'
        $.confirm({
            title: 'Confirm!',
            content: strContent,
            buttons: {
                confirm: {
                    btnClass: 'btn btn-success',
                    action: function () {
                        let datasend = {
                            Id: id,
                        };
                        LoadingShow();
                        PostDataAjax(action, datasend, function (response) {
                            LoadingHide();
                            if (response.rs) {
                                toastr.success(response.msg, "Success");
                                listFile = listFile.filter(x => x.guiId !== guiId);
                                viewFileSOP('all', 'view-file-checksheet');;
                            } else {
                                toastr.warning(response.msg, "Warning");
                            }
                        });
                    },
                },
                cancel: function () {
                },
            }
        });
    }
}
const clickView = (key, url, type = '') => {
    listFile = [];
    let action = baseUrl + url;
    let datasend = { Id: key }
    LoadingShow();
    PostDataAjax(action, datasend, function (response) {
        LoadingHide();
        if (response.rs) {
            listFile = response.fileAction;
            createModal_body();
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}

/// history
const loadHistory = (datas, active = false) => {

    $("#table_History").dataTable().fnDestroy();
    var table = $("#table_History").DataTable({
        "destroy": true,
        "lengthChange": true,
        "language": {
            "info": "Show _START_ - _END_ ( Total: _TOTAL_ )",
            "infoEmpty": "Showing 0 - 0 ",
            "infoFiltered": "( Total: _MAX_ )",
            "lengthMenu": "Show _MENU_ ",
            "search": "Search:",
            "loadingRecords": "Loading ... ",
            "paginate": {
                'previous': '<',
                'next': '>',
                'last': '>>',
                'first': '<<'
            },
        },
        "pageLength": 10,
        "filter": true, // this is for disable filter (search box)
        "orderMulti": false, // for disable multiple column at once
        "sort": false,
        "data": datas,
        "columns": [
            { "data": "SerialID", "autoWidth": false },
            { "data": "CodeSOP", "autoWidth": false },
            {
                "data": "FileName", "autoWidth": false,
                render: function (data, type, row) {
                    return `<b class="text-primary" onclick="clickView(${row.SerialID},'GetIDHistoryRecord')"> ${data}</b>`;
                },
            },
            { "data": "Notes", "autoWidth": false },
            { "data": "CreatedBy", "autoWidth": false },
            {
                "data": "CreatedDate", "autoWidth": false,
                render: function (data, type, row) {
                    var date = data != null ? moment(data).format('DD/MM/YYYY HH:mm:ss') : '';
                    return `${date}`;
                },
            },
            {
                data: "SerialID", "visible": active,
                render: function (data, type, row) {
                    var html = `<button type="button" onclick="confirmBackVerionChange(${data})" class="btn btn-sm btn-outline-warning">
                                <i class="fa fa-arrow-circle-o-left"></i>Back version</button>`;
                    return html;
                },
            },
        ],
        "columnDefs": [
            { "className": "text-center", "targets": "_all" },
        ],
    });

    if (active) {
        table.search('').draw();
    }
};
const historyChange = (key = 0, value = false) => {
    ;
    let action = baseUrl + "LoadHistory";
    let datasend = { Id: key, }
    LoadingShow();
    PostDataAjax(action, datasend, function (response) {
        LoadingHide();
        if (response.rs) {
            $("#modal_Historys").modal("show");
            loadHistory(response.data, value);
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const confirmBackVerionChange = (id) => {

    let action = baseUrl + "ConfirmBackVersionRecord";
    let datasend = {
        SerialID: id,
    }
    $.confirm({
        title: 'Confirm!',
        content: "Bạn chắc chắn muốn back version này không?",
        buttons: {
            confirm: {
                btnClass: 'btn btn-success',
                action: function () {
                    LoadingShow();
                    PostDataAjax(action, datasend, function (response) {
                        LoadingHide();
                        if (response.rs) {
                            myList = new ListItem();
                            loadData();
                            $("#modal_Historys").modal("hide");
                            $("#modal_Confirm").modal("hide");
                        }
                        else {
                            toastr.warning(response.msg, "Warning");
                        }
                    });
                },
            },
            cancel: function () {
                toastr.warning("Cancel the operation!", "Warning");
            },
        }
    });
}

/// Master
const masterRegister = () => {
    clearRegister();
    LoadDataMasterSOP();
    $("#modal_Register").modal("show");
};
const clearRegister = () => {
    $('#txtM_ID').val(0);
    $('#cboM_Type').val('2');
    $('#txtM_SOPName').val('');
};
const searchChange = () => {
    var value = $('#cboM_Type').val();
    var text = value == '1' ? 'Phân loại' : value == '2' ? 'Phòng ban' : value == '3' ? 'Công đoạn' : '';

    var table = $("#table_Register").DataTable();
    table.search(text).draw();
};
const LoadDataMasterSOP = () => {

    $("#table_Register").dataTable().fnDestroy();
    var table = $("#table_Register").DataTable({
        "destroy": true,
        "lengthChange": true,
        "language": {
            "info": "Show _START_ - _END_ ( Total: _TOTAL_ )",
            "infoEmpty": "Showing 0 - 0 ",
            "infoFiltered": "( Total: _MAX_ )",
            "lengthMenu": "Show _MENU_ ",
            "search": "Search:",
            "loadingRecords": "Loading ... ",
            "paginate": {
                'previous': '<',
                'next': '>',
                'last': '>>',
                'first': '<<'
            },
        },
        "lengthMenu": [6, 10, 25, 50, 100],
        "pageLength": 6,
        "filter": true, // this is for disable filter (search box)
        "orderMulti": false, // for disable multiple column at once
        "sort": false,
        "ajax": {
            url: baseUrl + "LoadDataMasterSOP",
            data: {},
            type: "POST",
            dataType: "json",
        },
        "columns": [
            { "data": "ID", "autoWidth": false },
            {
                "data": "Type", "autoWidth": false,
                render: function (data, type, row) {
                    var html = '';
                    switch (data) {
                        case "1":
                            html = "Phân loại";
                            break;
                        case "2":
                            html = "Phòng ban";
                            break;
                        case "3":
                            html = "Công đoạn";
                            break;
                    }
                    return html;
                },
            },
            { "data": "SOPName", "autoWidth": false },
            { "data": "Description", "autoWidth": false },
            {
                data: null,
                render: function (data, type, row) {
                    return `<div class="d-flex justify-content-center" >
                                            <button onclick='selectRegister(${row.ID})' class='btn btn-sm btn-outline-primary mr-1' title="Select"><i class="fa fa-hand-rock-o"></i></button>
                                            <button onclick='deleteRegister(${row.ID})' class='btn btn-sm btn-outline-danger' title-"Delete" > <i class="fa fa-trash"></i></button >
                             </div>`;
                },
            },
        ],
        "columnDefs": [
            { "className": "text-center","targets": [0, 4] },
        ],
    });
};
const selectRegister = (id) => {
    let action = baseUrl + 'GetIdSOPMasterRecord';
    let datasend = {
        ID: id,
    }
    PostDataAjax(action, datasend, function (response) {
        if (response.rs) {
            let datas = response.data;
            $('#txtM_ID').val(datas.ID);
            $('#cboM_Type').val(datas.Type);
            $('#txtM_SOPName').val(datas.SOPName);
            $('#txtM_Description').val(datas.Description);
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const updateRegister = (value) => {
    let id = $("#txtM_ID");
    let type = $("#cboM_Type");
    let SOPName = $("#txtM_SOPName");
    let Description = $("#txtM_Description");

    if (!IsNullOrEmpty("warning", type, " Type can not be empty or null")
        || !IsNullOrEmpty("warning", SOPName, " SOPName can not be empty or null"))
        return false;

    let action = baseUrl + 'UpdateSOPRecord';
    let models = {
        ID: value == 'add' ? 0 : id.val(),
        Type: type.val().trim(),
        SOPName: SOPName.val().trim(),
        Description: Description.val().trim(),
    };
    LoadingShow();
    PostDataAjax(action, models, function (response) {
        LoadingHide();
        if (response.rs) {
            toastr.success(response.msg, "Success");
            LoadDataMasterSOP();
            clearRegister();
        }
        else {
            toastr.warning(response.msg, "Warning");
        }
    });
}
const deleteRegister = (id) => {
    let action = baseUrl + 'DeleteSOPRecord';
    let strContent = 'Are you sure you want to delete?'
    $.confirm({
        title: 'Confirm!',
        content: strContent,
        buttons: {
            confirm: {
                btnClass: 'btn btn-success',
                action: function () {
                    let datasend = {
                        Id: id,
                    };
                    LoadingShow();
                    PostDataAjax(action, datasend, function (response) {
                        LoadingHide();
                        if (response.rs) {
                            toastr.success(response.msg, "Success");
                            LoadDataMasterSOP();
                            clearRegister();
                        } else {
                            toastr.warning(response.msg, "Warning");
                        }
                    });
                },
            },
            cancel: function () {
            },
        }
    });
}

/// Excel
const importFile = () => {
    $("#txt_ImportFile").val('');
    $("#txt_ImportFile").click();
}
const importChange = () => {
    if (window.FormData !== undefined) {
        let fileUpload = $("#txt_ImportFile").get(0);
        let files = fileUpload.files;
        let fileData = new FormData();
        for (let i = 0; i < files.length; i++) {
            fileData.append("file" + i, files[i]);
        }
        LoadingShow();
        $.ajax({
            url: baseUrl + 'UploadImportData',
            method: 'POST',
            contentType: false,
            processData: false,
            data: fileData,
            success: function (result) {
                LoadingHide();
                if (result.rs) {
                    loadData();
                    toastr.success(result.msg, "Success");
                } else {
                    toastr.warning(result.msg, "Warning");
                }
            },

        });
    }
    else {
        toastr.error("FormData is not supported.");
    }
}


/// function
const checkVersion = () => {

    var oldName = $('#txt_CodeSopOld').val();
    var name = $('#txt_CodeSop').val();

    // Lấy ký tự cuối cùng
    var lastOldName = oldName.charAt(oldName.length - 1);
    var lastName = name.charAt(name.length - 1);

    var value = $('#txt_StatusAction').val();
    if (value == 'add') {
        // Kiểm tra xem ký tự cuối cùng có phải là một chữ cái không
        if (lastName.match(/[a-zA-Z]/)) {
            if (lastName.toUpperCase() !== "A") {
                toastr.warning("Version đầu tiên phải là ........A ", "Warning");
                $('#txt_CodeSop').val('');
            }
        }
    } else if (value == 'edit') {
        if (oldName !== name) {
            toastr.warning(`Version không được thay đổi: ${oldName}`, "Warning");
            $('#txt_CodeSop').val('')
        }
    } else {

        // Tăng ký tự cuối cùng lên một đơn vị trong bảng chữ cái
        var nextCharCode = lastOldName.charCodeAt(0) + 1;
        var nextChar = String.fromCharCode(nextCharCode);
        // Gán giá trị mới cho biến name
        var newName = name.slice(0, -1) + nextChar;

        if (oldName.includes(name.slice(0, -1))) {
            if (newName !== name) {
                toastr.warning(`Gợi ý version hợp lệ: ${newName}`, "Warning");
                $('#txt_CodeSop').val('')
            }
        } else {
            toastr.warning(`Chỉ được thay đổi version không được thay đổi tên file: ${oldName.slice(0, -1) + nextChar}`, "Warning");
            $('#txt_CodeSop').val('')
        }
    }
}
const setupToFileName = () => {
    var iType = $('#cbo_Type').val();
    var type = '';
    if (listFile.length > 0) {

        var fileName = listFile[0].FileName;
        var name = fileName.split('.')[0];
        $('#txt_CodeSop').val(name);

        var value = $('#txt_StatusAction').val();

        var count = fileName.split('-');
        switch (count.length) {
            case 1:
                type = "KF";
                break;
            case 2:
                type = count[1].substring(0, 2);
                $('#cbo_Type').val(type);
                var checkValue = $('#cbo_Type').val();
                if (checkValue == null) {
                    type = count[0].substring(0, 1);
                }
                break;
            case 3:
                type = count[0];
                break;
        }
        $('#cbo_Type').val(type);

        if (value != "add") {
            if (type !== iType) {
                toastr.warning("File không thuộc phân loại trước đó!", "Warning");
            }
            $('#cbo_Type').val(iType);
        }
    }

    checkVersion();

}

const mailChange = (idIn, idOut) => {
    var value = $(`#${idIn}`).val();
    var mail = $(`#${idOut}`).val();

    if (value.length > 0) {
        var mails = value.join(",");
        $(`#${idOut}`).val(mails);
    } else {
        $(`#${idOut}`).val('');
    }
    //$(`#${idIn}`).val('')
}


